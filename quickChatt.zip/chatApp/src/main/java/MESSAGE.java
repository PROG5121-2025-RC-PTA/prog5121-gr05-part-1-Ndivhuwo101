
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


public class MESSAGE {
    
    private String MessageID ;
    private String RecipientCell;
    private String message;
   static int MessageNumber = 0;
   static int msgCount = 0;
public MESSAGE(){
    //CONSTRUCTORS USED
    this.MessageID = MessageID ;
    this.RecipientCell = RecipientCell;
    this.MessageNumber = MessageNumber;
    this.msgCount= msgCount;
} 

   
    //method checks messageID
    static Boolean checkMessageID(String MessageID){
        if( MessageID.length() == 10){
            return true;
        }else{
            return false;
        }
    }
    //CHECKING requirments for recipient cellphone number
    static int checkRecipientCell(String RecipientCell){
        if(RecipientCell.matches("^\\+\\d{1,3}\\d{1,1}$")){
           
        }
        return +27;
    }   
    //method will make Messagehash out of messages sent
    static String createMessageHash(String MessageID,String message){
        
        String MessageIDStr = String.valueOf(MessageID);
        String fwgt = MessageIDStr.substring(0, 2);
        int messageNumber = message.length();
        String[]words = message.split("\\s+");
        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length-1].toUpperCase();
        String messageHash = String.format("%s:%d:%s%s", fwgt,messageNumber,firstWord,lastWord);
      return messageHash;
    }
//loops are used for sentMessages
static String sentMessage(String message){
Scanner insert =new Scanner(System.in);

for(int i =0;i<= MessageNumber;i++){
if(i > MessageNumber){
    System.out.println("Invalid");  
msgCount++;
}else{
    System.out.println("you may continue");
    msgCount++;
}
}
 System.out.println("\nChoose an option:\n1) Send Messages\n2) Show recently sent messages\n3) Quit");
    int choice = insert.nextInt();
            
    switch (choice) {
     case 1:
         System.out.println("Message sent");;
      break;
    case 2:
      System.out.println("Coming Soon.");
     break;
    case 3:
      System.out.println("Exiting...");
     break;
     default:
         System.out.println("Invelid");
    }
    return message;
}
// all messages are the printed
public String PrintMESSAGE(String Message){
   return message; 
}
//number of messages are shown
public int TotalMessage(int msgCount){
        return msgCount;
}
//method that stores messages
 public void MessageSavedToJson() {
        try (FileWriter file = new FileWriter("messages.json")) {
            file.write(message);
            file.flush();
            System.out.println("Messages saved to messages.json");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
    
   