/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapp;

import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class ChatApp {


            
    private static String regUser ;
    private static String regPass;
    private static String regCell;
    
  Scanner input = new Scanner(System.in);   
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        //prompting for details
        System.out.println("Wellcome to quick chatt");
        System.out.println("register your username");
        regUser = input.nextLine();
        System.out.println("register your password");
        regPass = input.nextLine();
        System.out.println("register cellphone number");
        regCell = input.next();
         
    }
    public static Boolean UserRequier(String regUser,String regPass) {
        
        //checking username and password requirments
    if( !regUser.matches(".*[^a-zA-Z0-9].*")) {
        System.out.println("error");
      if(regPass.length()!= 8) { 
            System.out.println("Password must be 8 chareckters long");
      }
    }else{
    
  boolean hasUppercase = regPass.matches(".*[A-Z].*");
  boolean hasDigit = regPass.matches(".*\\d.*");
  boolean hasSpecialChar = regPass.matches(".*[^a-zA-Z0-9].*");
    
  if(!hasUppercase || !hasDigit || !hasSpecialChar) {
      System.out.println("Password must contain at least one uppercase letter, " + "one digit, and one special character.");
  }
    }
    return true;
  }
    
   
    
    /**
     *
     * @return
     */
     private String User;
    private String Password;
    public Boolean Login(String regUser,String regPass, boolean Login){
      
        Scanner input = new Scanner(System.in);
        
        //prompting user
        System.out.println("enter your username");
        User = input.next();
        System.out.println("enter your password");
        Password = input.next();
       
        //checking if username is equal
        if(User == regUser){
            
            if(Password == regPass){
                
                return true;
            }else{
               
                System.out.println("incorect Username");
                
        }
         return true;     
        }else{
            return false;
        
        }
    }
    public void Welcome(boolean Login, int choice){
        
       //Calling the class 
       MESSAGE GraceObj =new MESSAGE();
       
   while(Login =true) {
       System.out.println("Welcome to QuickChat.");
        
        System.out.println("Choose an option:");
        System.out.println("1) Send Messages");
        System.out.println("2) Show recently sent messages");
        System.out.println("3) Quit");
        choice = input.nextInt();
        choice = input.nextInt();   
       switch (choice) {
     case 1:
         System.out.println("Message sent");;
      break;
    case 2:
      System.out.println("Coming Soon.");
     break;
    case 3:
      System.out.println("Exiting...");
     break;
     default:
         System.out.println("Invelid");
         
       }
    }
   }
    
}
        
    


